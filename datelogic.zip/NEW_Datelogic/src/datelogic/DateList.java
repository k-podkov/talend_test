package datelogic;

public class DateList {
		private String DD;
		private String MM;
		private String YY;
		private String YYYY;
		private String MMDD;
		private String YYMM;
		private String YYMMDD;
		private String YYYYMMDD;
		private String YYYYMM;
		private String DDMMMYY;
		private String DDMMYYYY;
		private String DATE_STR;
		private String DATE_STR2;
		private String DATE_STR3;
		private String DATE_STR4;
		private String DATE_STR5;
		private String MTH_STR;
 	    private String WEEKDAY;
  	    private int rollNo;
  	    //
  	    private String PRVBD_YYMMDD;
  	    private String PRVBD_YYYYMMDD;

	/*   DateList(String yyyymmdd, int rollNo){
	      this.YYYYMMDD = yyyymmdd;
	      this.rollNo = rollNo;
	   }*/

	   public String getName() {
	      return YYYYMMDD;
	   }

	   public String getDD() {
		return DD;
	}

	public void setDD(String dD) {
		DD = dD;
	}

	public String getMM() {
		return MM;
	}

	public void setMM(String mM) {
		MM = mM;
	}

	public String getYY() {
		return YY;
	}

	public void setYY(String yY) {
		YY = yY;
	}

	public String getYYYY() {
		return YYYY;
	}

	public void setYYYY(String yYYY) {
		YYYY = yYYY;
	}

	public String getMMDD() {
		return MMDD;
	}

	public void setMMDD(String mMDD) {
		MMDD = mMDD;
	}

	public String getYYMM() {
		return YYMM;
	}

	public void setYYMM(String yYMM) {
		YYMM = yYMM;
	}

	public String getYYMMDD() {
		return YYMMDD;
	}

	public void setYYMMDD(String yYMMDD) {
		YYMMDD = yYMMDD;
	}

	public String getYYYYMMDD() {
		return YYYYMMDD;
	}

	public void setYYYYMMDD(String yYYYMMDD) {
		YYYYMMDD = yYYYMMDD;
	}

	public String getYYYYMM() {
		return YYYYMM;
	}

	public void setYYYYMM(String yYYYMM) {
		YYYYMM = yYYYMM;
	}

	public String getDDMMMYY() {
		return DDMMMYY;
	}

	public void setDDMMMYY(String dDMMMYY) {
		DDMMMYY = dDMMMYY;
	}

	public String getDDMMYYYY() {
		return DDMMYYYY;
	}

	public void setDDMMYYYY(String dDMMYYYY) {
		DDMMYYYY = dDMMYYYY;
	}

	public String getDATE_STR() {
		return DATE_STR;
	}

	public void setDATE_STR(String dATE_STR) {
		DATE_STR = dATE_STR;
	}

	public String getDATE_STR2() {
		return DATE_STR2;
	}

	public void setDATE_STR2(String dATE_STR2) {
		DATE_STR2 = dATE_STR2;
	}

	public String getDATE_STR3() {
		return DATE_STR3;
	}

	public void setDATE_STR3(String dATE_STR3) {
		DATE_STR3 = dATE_STR3;
	}

	public String getDATE_STR4() {
		return DATE_STR4;
	}

	public void setDATE_STR4(String dATE_STR4) {
		DATE_STR4 = dATE_STR4;
	}

	public String getDATE_STR5() {
		return DATE_STR5;
	}

	public void setDATE_STR5(String dATE_STR5) {
		DATE_STR5 = dATE_STR5;
	}

	public String getMTH_STR() {
		return MTH_STR;
	}

	public void setMTH_STR(String mTH_STR) {
		MTH_STR = mTH_STR;
	}

	public String getWEEKDAY() {
		return WEEKDAY;
	}

	public void setWEEKDAY(String wEEKDAY) {
		WEEKDAY = wEEKDAY;
	}

	public void setName(String name) {
	      this.YYYYMMDD = name;
	   }

	   public int getRollNo() {
	      return rollNo;
	   }

	   public void setRollNo(int rollNo) {
	      this.rollNo = rollNo;
	   }

	public String getPRVBD_YYMMDD() {
		return PRVBD_YYMMDD;
	}

	public void setPRVBD_YYMMDD(String pRVBD_YYMMDD) {
		PRVBD_YYMMDD = pRVBD_YYMMDD;
	}

	public String getPRVBD_YYYYMMDD() {
		return PRVBD_YYYYMMDD;
	}

	public void setPRVBD_YYYYMMDD(String pRVBD_YYYYMMDD) {
		PRVBD_YYYYMMDD = pRVBD_YYYYMMDD;
	}
	   
	}
