package datelogic;

public class DemoRun {
	   public static void main(String[] args) {
	      Interfaces studentDao = new Logic();
	      DateList datelogic = studentDao.initialize("20150524");
	      System.out.println(datelogic.getYYMMDD());
	      System.out.println(datelogic.getYYYYMMDD());
	      System.out.println(datelogic.getPRVBD_YYMMDD());
	      System.out.println(datelogic.getPRVBD_YYYYMMDD());
	   }
	}