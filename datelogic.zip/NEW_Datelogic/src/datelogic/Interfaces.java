package datelogic;

public interface Interfaces {
   public DateList initialize(String date);
}
