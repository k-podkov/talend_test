package datelogic;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Logic implements Interfaces {
	SimpleDateFormat sdf;
	Calendar cal = Calendar.getInstance();
	
   @Override
   public DateList initialize(String inDate) {
	   DateList workingList = new DateList();
	   String outDate;
	   Date date=null;
	   try {
		   sdf = new SimpleDateFormat("yyyyMMdd");
		   date = sdf.parse(inDate);
	   } catch (ParseException e) {
		   e.printStackTrace();
	   }
	   
	   
	   sdf = new SimpleDateFormat("yyyyMMdd");
	   workingList.setYYYYMMDD(sdf.format(date));
	   
	   sdf = new SimpleDateFormat("yyMMdd");
	   workingList.setYYMMDD(sdf.format(date));
	   
	   //
	   // PRVBD Logic
	   //
	   cal.setTime(date);
	   cal.add(cal.DATE,-1);
	   sdf = new SimpleDateFormat("yyMMdd");
	   workingList.setPRVBD_YYMMDD(sdf.format(cal.getTime()));
	   sdf = new SimpleDateFormat("yyyyMMdd");
	   workingList.setPRVBD_YYYYMMDD(sdf.format(cal.getTime()));
	   
	   return workingList;
   }
}